public class Test {
    public static void main(String[] args) {
        Orchid orchid1 = new Orchid ("Phalaenopsis orchid", "blue", 4, 20, "Moth Orchid");

    }
}

/*
@Test
    void setName(){
    Orchid orchid1 = new Orchid ("Phalaenopsis orchid", "red", 5, 30, "Moth Orchid");
    assertEquals("The orchid type: Moth orchid",orchid.toString());
}
 */